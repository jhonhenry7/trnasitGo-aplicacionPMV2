# Contreras-Inga-Sanchez-PMV2
### Equipo
- Contreras Anton, Alex Ricardo
- Inga Barzola, Emil Hristo
- Sanchez Taipe, Jordan Geralmy
# Producto Academico 3
Este repositorio contiene el informe de nuestro proyecto.
## Descripción
En este informe, se detallan los resultados y hallazgos de la Unidad I por el momento.
## Contenido 
El informe se encuentra en formato PDF y puede ser accedido aqui.
## Instalación y Uso
Sigue estos pasos para configurar y ejecutar la aplicación en tu entorno local:
````markdown
git clone https://github.com/Jordan02S/Contreras-Inga-Sanchez-PMV2.git
````
Una vez teniendo los archivos, los importas desde AndroidStudio
